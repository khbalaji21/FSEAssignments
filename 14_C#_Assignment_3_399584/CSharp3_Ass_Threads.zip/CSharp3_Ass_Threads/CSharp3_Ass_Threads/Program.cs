﻿using System;
using System.Threading;

namespace CSharp3_Ass_Threads
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Account account = new Account(1234, "Balaji Singh", "Kurnool", 50000);
            Console.WriteLine("---------------------------------------------");
            //account.withdrawl(6678.75);

            // Two ways to create threads in C#
            //ThreadStart threadstart_withdrawl = new ThreadStart(account.withdrawl(6678.75));
            //ThreadStart threadstart_deposit = new ThreadStart(account.deposit(50000));

            //Thread thread_withdrawl = new Thread(threadstart_withdrawl);
            //Thread thread_deposit = new Thread(threadstart_deposit);

            //Thread thread_withdrawl = new Thread(new ThreadStart(account.withdrawl));
            //Thread thread_deposit = new Thread(new ThreadStart(account.deposit));
            // Both ways are correct

            Thread thread_withdrawl = new Thread(() => account.withdrawl(5000));
            Thread thread_deposit = new Thread(() => account.deposit(50000));

            thread_withdrawl.Start();
            thread_deposit.Start();

            thread_withdrawl.Join();
            thread_deposit.Join();

            Console.ReadLine();
        }
    }
    public class Account
    {
        static object locker = new object();
        public int acc_no { get; set; }
        public string cust_name { get; set; }
        public string cust_address { get; set; }
        public double acc_bal { get; set; }
        public Account()
        {

        }
        public Account(int ac_number, string customer_nm, string cust_add, double ac_balance)
        {
            acc_no = ac_number;
            cust_name = customer_nm;
            cust_address = cust_add;
            acc_bal = ac_balance;
        }
        public void withdrawl(double amount_withdrawn)
        {
            for (int i = 0; i < 10; i++)
            {
                Monitor.Enter(locker);
                acc_bal = acc_bal - amount_withdrawn;
                Console.WriteLine("5K debited by withdrawl thread, The balance in the account is " + acc_bal);
                Thread.Yield();
            }
        }
        public void deposit(double amount_deposited)
        {
            for (int i = 0; i < 10; i++)
            {
                Monitor.Enter(locker);
                acc_bal = acc_bal + amount_deposited;
                Console.WriteLine("50K added by deposit thread, The balance in the account is " + acc_bal);
                Thread.Yield();
            }
        }
    }
}
