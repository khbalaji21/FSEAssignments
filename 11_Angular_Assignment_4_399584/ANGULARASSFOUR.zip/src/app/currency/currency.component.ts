import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';

@Component({
  selector: 'app-currency',
  templateUrl: './currency.component.html',
  styleUrls: ['./currency.component.css']
})
export class CurrencyComponent implements OnInit {

    full_json: string = "";
    constructor(private _sharedService: SharedService) { }

    ngOnInit() {
        this.getCurrencyinfo()
    }

    getCurrencyinfo() {
        this._sharedService.getcurr("INR")
            .subscribe(
            jsonresult => {
                this.full_json = JSON.stringify(jsonresult["query"]["results"]["channel"]);
            }
            );
    }

}
