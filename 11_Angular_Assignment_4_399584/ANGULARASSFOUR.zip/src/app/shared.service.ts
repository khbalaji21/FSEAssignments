import { Injectable } from '@angular/core';
import { Http, Headers, Response } from "@angular/http";
import { Observable } from "rxjs";
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class SharedService {

    url_for_weather = "https://query.yahooapis.com/v1/public/yql?q=select%20*%20from%20weather.forecast%20where%20woeid%20in%20(select%20woeid%20from%20geo.places(1)%20where%20text%3D%22";
    weather_followup_url = "%22)&format=json&env=store%3A%2F%2Fdatatables.org%2Falltableswithkeys";
    url_for_movie = "http://www.omdbapi.com/?t=";
    movie_followup_url = "&y=&plot=short&r=json"; 
    currencyURL = "http://api.fixer.io/latest?symbols="; 
    hits: number = 0;

    constructor(private _http: Http) { }

    getweather(city, state) {
        this.hits = this.hits + 1;
        return this._http.get(this.url_for_weather + city + "%2C%20" + state + this.weather_followup_url)
            .pipe(
            map((response: Response) => {
                { return response.json() };
            }))
    }

    getmovies(movie) {
        this.hits = this.hits + 1;
        return this._http.get(this.url_for_movie + movie + this.movie_followup_url)
            .pipe(
            map((response: Response) => {
                { return response.json() };
            }))
    }

    getcurr(currency) {
        this.hits = this.hits + 1;
        return this._http.get(this.currencyURL + currency)
            .pipe(
            map((response: Response) => {
                { return response.json() };
            }))
    }
}
