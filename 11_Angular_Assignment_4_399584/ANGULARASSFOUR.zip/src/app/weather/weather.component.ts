import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';

@Component({
    selector: 'app-weather',
    templateUrl: './weather.component.html',
    styleUrls: ['./weather.component.css']
})
export class WeatherComponent implements OnInit {
    city: string = "";
    state: string = "";
    _city: string = "";
    _region: string = "";
    _country: string = "";
    _date: string = "";
    _text: string = "";
    _temp: string = "";
    constructor(private _sharedService: SharedService) { }

    ngOnInit() {
    }

    WeatherService() {
        this._sharedService.getweather(this.city, this.state)
            .subscribe(
            lstresult => {
                this._city = lstresult["query"]["results"]["channel"]["location"]["city"];
                this._region = lstresult["query"]["results"]["channel"]["location"]["region"];
                this._country = lstresult["query"]["results"]["channel"]["location"]["country"];
                this._date = lstresult["query"]["results"]["channel"]["item"]["condition"]["date"];
                this._text = lstresult["query"]["results"]["channel"]["item"]["condition"]["text"];
                this._temp = lstresult["query"]["results"]["channel"]["item"]["condition"]["temp"];
            }
            );
    }

}