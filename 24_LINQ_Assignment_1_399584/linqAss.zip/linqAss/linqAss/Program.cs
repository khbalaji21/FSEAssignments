﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace linqAss
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("1. Given an array of numbers. Find the cube of the numbers that are greater than 100 but less than 1000 using LINQ");
            Console.WriteLine("\n--------------------------------------------------------------");
            linqQ1();

            Console.ReadLine();
        }

        public static void linqQ1()
        {
            // 1. Given an array of numbers. Find the cube of the numbers that are greater than 100 but less than 1000 using LINQ. 
            // Change some of the array elements and execute the same query again. Hint: use the logical operators of C# to combine the conditions

            Console.WriteLine("Input the array size");
            int arrSize = int.Parse(Console.ReadLine());
            Console.WriteLine("Input the array element");
            int[] arr = new int[arrSize];
            for (int i = 0; i < arrSize; i++)
            {
                arr[i] = int.Parse(Console.ReadLine());
            }
            var cubesG100L1000 = from int element in arr
                                 let cube = element * element * element
                                 where cube > 100 && cube < 1000
                                 select new { element, cube };
            Console.WriteLine("The cubes divisible by 3 are");
            foreach (var element in cubesG100L1000)
                Console.WriteLine(element);

        }

        public static void linqQ3()
        {

        }
    }

    public class Order
    {
        public int Order_id { get, set}
    }
}
