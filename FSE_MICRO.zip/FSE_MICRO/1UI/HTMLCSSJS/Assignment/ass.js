document.addEventListener("DOMContentLoaded", function() { initialiseMediaPlayer(); }, false);
var vid = document.getElementById('vidhtml5');
var progressBar = document.getElementById('vidProgress');
var playBtn = document.getElementById('playbtn');
var pauseBtn = document.getElementById('pausebtn');
var stopBtn = document.getElementById('stopbtn');


function initialiseMediaPlayer() {	
	vid.addEventListener('timeupdate', videoProgress, false);
	disablePauseStopButtons();
	localStorage.noOfDislikes = 0;
	localStorage.noOflikes = 0;	
}

window.onresize = function (event) {
	applyOrientation();
}

function play()
{	
	disablePlayButton();
	enablePauseStopButtons();
	vid.play();	
}

function pause()
{	
	disablePauseStopButtons();
	enablePlayButton();
	vid.pause();
}

function stop()
{	
	disablePauseStopButtons();
	enablePlayButton();
	progressBar.value = 0;
	vid.load();
}

function incVol()
{
	vol = vid.volume;
	vid.volume = vol + 0.1;
}

function decVol()
{
	vol = vid.volume;
	vid.volume = vol - 0.1;
}

function mute()
{	
	if(vid.muted)
	{
		vid.muted = false;
	}
	else
	{
		vid.muted = true;
	}
}

function videoProgress()
{
	var pcnt = Math.floor((100 / vid.duration) * vid.currentTime);	
	progressBar.value = pcnt;
	progressBar.innerHTML = pcnt + '% played';
}

function disablePlayButton()
{	
	playBtn.classList.add('disablebtn');
	playBtn.disabled=true;
}

function enablePlayButton()
{
	playBtn.classList.remove('disablebtn');
	playBtn.disabled=false;
}

function disablePauseStopButtons()
{		
	pauseBtn.classList.add("disablebtn");
	stopBtn.classList.add("disablebtn");
	pauseBtn.disabled=true;
	stopBtn.disabled=true;
}

function enablePauseStopButtons()
{	
	pauseBtn.classList.remove("disablebtn");
	stopBtn.classList.remove("disablebtn");
	pauseBtn.disabled=false;
	stopBtn.disabled=false;
}

function likes()
{
	
	localStorage.setItem('noOflikes',parseInt(localStorage.getItem('noOflikes'))+1);
	alert("No of Likes for this video are "+localStorage.getItem('noOflikes'));
}

function dislikes() 
{
	
	localStorage.setItem('noOfDislikes',parseInt(localStorage.getItem('noOfDislikes'))+1);
	alert("No of Dislikes for this video are "+localStorage.getItem('noOfDislikes'));
}

function applyOrientation() {
  //if (window.innerHeight > window.innerWidth) {
  // alert("You are now in portrait");
  //} else {
  //  alert("You are now in landscape");
  //}
}

function changevideo(id)
{
	if(id === "introToHTML5")
	{
		var getSource = document.getElementById("sourceVideo");
		getSource.setAttribute('src', 'https://youtu.be/x4OKqZ2kIx4');
		vid.load();
		play();
	}
	else if(id === "introToCSS3"){
		var getSource = document.getElementById("sourceVideo");
		getSource.setAttribute('src', 'https://youtu.be/vkCOfmqG6ys');
		vid.load();
		play();
	}		
	else if(id === "introToBstrap4"){
		var getSource = document.getElementById("sourceVideo");
		getSource.setAttribute('src', 'https://youtu.be/QAgrHLtG1Yk');
		vid.load();
		play();
	}
	else if(id === "HTML5CSS3BS4"){	
		var getSource = document.getElementById("sourceVideo");
		getSource.setAttribute('src', 'https://youtu.be/9cKsq14Kfsw');
		vid.load();
		play();
	}
	else if(id === "javaScript"){	
		var getSource = document.getElementById("sourceVideo");
		getSource.setAttribute('src', 'https://youtu.be/zGWwutqP3u0');
		vid.load();
		play();
	}
}

