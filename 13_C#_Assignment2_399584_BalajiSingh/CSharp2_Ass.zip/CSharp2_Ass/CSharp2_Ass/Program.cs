﻿using System;

namespace CSharp2_Ass
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Person[] personArray = new Person[5];
            personArray[0] = new Professor("Zareena", 9);
            personArray[1] = new Professor("Bhogeerappa", 1);
            personArray[2] = new Professor("Farzana", 11);
            personArray[3] = new Student("Balaji Singh", 85.75);
            personArray[4] = new Student("Rakesh Arveti", 52.69);
            //Professor zareena = new Professor("Zareena", 9);
            //Professor Bhogeerappa = new Professor("Bhogeerappa", 1);
            //Professor farzana = new Professor("Farzana", 11);
            //Student balaji = new Student("Balaji Singh", 84.75);
            //Student rakesh = new Student("Rakesh Arveti", 52.69);

            foreach (Person person in personArray)
            {
                if (person.isOutstanding())
                {
                    if (person.GetType() == typeof(Professor))
                    {
                        person.print();
                    }
                    else
                    {
                        person.display();
                    }
                }
            }
            Console.ReadLine();
        }
    }

    public class Person
    {
        protected string name { get; set; }
        public Person()
        {

        }
        public Person(string personName)
        {
            name = personName;
        }
        public string getName()
        {
            return name;
        }
        public void setName(string personName)
        {
            name = personName;
        }
        public virtual bool isOutstanding()
        {
            return false;
        }
        public virtual void print()
        {

        }
        public virtual void display()
        {

        }
    }

    public class Professor : Person
    {
        Person person = new Person();
        public int booksPublished { get; set; }
        public Professor()
        {

        }
        public Professor(string ProfessorName, int noOfbooks)
        {
            person.setName(ProfessorName);
            booksPublished = noOfbooks;
        }
        public override void print()
        {
            Console.WriteLine("\n-----------------------------");
            Console.WriteLine("The Person is a Professor");
            Console.WriteLine("The Professor Name is " + person.getName());
            Console.WriteLine("Number of books published by Professor are " + booksPublished);
        }
        public override bool isOutstanding()
        {
            if (booksPublished < 4)
                return false;
            else
                return true;
        }
    }

    public class Student : Person
    {
        Person person = new Person();
        public double percentage { get; set; }
        public Student()
        {

        }
        public Student(string StudentName, double Studentpercentage)
        {
            person.setName(StudentName);
            percentage = Studentpercentage;
        }
        public override void display()
        {
            Console.WriteLine("\n-----------------------------");
            Console.WriteLine("The Person is a Student");
            Console.WriteLine("The Student Name is " + person.getName());
            Console.WriteLine("The percentage of the Student is " + percentage);            
        }
        public override bool isOutstanding()
        {
            if (percentage < 85)
                return false;
            else
                return true;
        }
    }
}
