import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HttpModule } from '@angular/http';

import { AppComponent } from './app.component';
import { MenuComponent } from './menu/menu.component';
import { WeatherComponent } from './weather/weather.component';
import { MovieComponent } from './movie/movie.component';
import { CurrencyComponent } from './currency/currency.component';
import { SharedService } from "./shared.service";
import { FormsModule } from '@angular/forms';

const appRoutes: Routes = [
    { path: 'Menu', component: MenuComponent },
    { path: 'Weather', component: WeatherComponent },
    { path: 'Movie', component: MovieComponent },
    { path: 'Currency', component: CurrencyComponent },
    { path: '', redirectTo: '/Menu', pathMatch: 'full' }
];

@NgModule({
  declarations: [
    AppComponent,
    MenuComponent,
    WeatherComponent,
    MovieComponent,
    CurrencyComponent
  ],
  imports: [
      FormsModule,
      BrowserModule,
      RouterModule.forRoot(appRoutes),
      HttpModule
  ],
  providers: [SharedService],
  bootstrap: [AppComponent]
})
export class AppModule { }
