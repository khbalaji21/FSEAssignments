import { Component, OnInit } from '@angular/core';
import { SharedService } from '../shared.service';

@Component({
    selector: 'app-weather',
    templateUrl: './weather.component.html',
    styleUrls: ['./weather.component.css']
})
export class WeatherComponent implements OnInit {
    full_json: string = "";
    constructor(private _sharedService: SharedService) { }

    ngOnInit() {
        this.getWeatherinfo()
    }

    getWeatherinfo() {
        this._sharedService.getweather("San Francisco", "")
            .subscribe(
            jsonresult => {
                this.full_json = JSON.stringify(jsonresult["query"]["results"]["channel"]);
            }
            );
    }

}
